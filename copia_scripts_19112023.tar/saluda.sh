#!/bin/bash
while [ 1 ];do
sleep 2
echo hola "Pedro García"
done
